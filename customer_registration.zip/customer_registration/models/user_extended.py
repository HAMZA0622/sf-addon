from odoo import models, fields

class ResUserExtended(models.Model):
    _name = 'x_res_user_extended'
    _description = 'Extended User Information'
    _rec_name = 'user_id'  
    
    user_id = fields.Many2one(
        'res.users',
        string='Related User',
        required=True,
        ondelete='cascade',
        inverse_name='extended_info_id'  # Must match exactly
    )

    telephone = fields.Char(string="Telephone")
    occupation = fields.Selection([
        ('designer', 'Designer'),
        ('architect', 'Architect'),
        ('engineer', 'Engineer'),
        ('other', 'Other')],
        string="Occupation")
    sales_rep = fields.Char(string="Sales Representative")
    company = fields.Char(string="Company")
    address1 = fields.Char(string="Address 1")
    address2 = fields.Char(string="Address 2")
    city = fields.Char(string="City")
    postcode = fields.Char(string="Postcode")
    country_id = fields.Many2one('res.country', string="Country")
    state_id = fields.Many2one('res.country.state', string="State")
    subscribe = fields.Boolean(string="Newsletter Subscription", default=True)

    _sql_constraints = [
        ('user_id_unique', 'unique(user_id)', 'Each user can only have one extended information record!')
    ]
