from odoo import models, fields

class CustomerRegistration(models.Model):
    _inherit = 'res.users'

    # Changed to Many2one for 1:1 relationship
    extended_info_id = fields.Many2one(
        'x_res_user_extended',
        string='Extended Info',
        ondelete='cascade'
    )

     # Add related fields with proper configuration
    telephone = fields.Char(related='extended_info_id.telephone', readonly=False)
    occupation = fields.Selection(related='extended_info_id.occupation', readonly=False)
    sales_rep = fields.Char(related='extended_info_id.sales_rep', readonly=False)
    company = fields.Char(related='extended_info_id.company', readonly=False)
    address1 = fields.Char(related='extended_info_id.address1', readonly=False)
    address2 = fields.Char(related='extended_info_id.address2', readonly=False)
    city = fields.Char(related='extended_info_id.city', readonly=False)
    postcode = fields.Char(related='extended_info_id.postcode', readonly=False)
    country_id = fields.Many2one(related='extended_info_id.country_id', readonly=False)
    state_id = fields.Many2one(related='extended_info_id.state_id', readonly=False)
    subscribe = fields.Boolean(related='extended_info_id.subscribe', readonly=False)
