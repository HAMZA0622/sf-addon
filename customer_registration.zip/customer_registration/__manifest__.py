{
    'name': 'Customer Registration',
    'version': '1.0',
    'category': 'Website',
    'summary': 'Customer Registration form.',
    'author': 'Meer Zaman Khattak',
    'depends': ['base', 'portal', 'website'],
    'data': [  
        'security/ir.model.csv',  # Must come first
        'security/ir.model.access.csv',
        'data/email_template.xml',
        'views/customer_registration_templates.xml',
        'views/user_extended_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}