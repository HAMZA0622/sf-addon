import logging
from odoo import http, _
from odoo.addons.auth_signup.models.res_users import SignupError
from odoo.exceptions import UserError
from odoo.http import request

_logger = logging.getLogger(__name__)

class CustomerRegistration(http.Controller):

    def _prepare_signup_values(self, post):
        """ Prepare user data for res.users. """
        first_name = post.get('first_name')
        last_name = post.get('last_name')
        email = post.get('email')
        password = post.get('password')
        confirm_password = post.get('confirm_password')

        # Validate password confirmation
        if password != confirm_password:
            raise UserError(_("Passwords do not match; please retype them."))

        # Check if the user already exists
        existing_user = request.env['res.users'].sudo().search([('login', '=', email)], limit=1)
        if existing_user:
            raise SignupError(_("A user with this email already exists."))

        # Get Portal Group Reference
        portal_group = request.env.ref('base.group_portal')

        return {
            'name': f"{first_name} {last_name}",  # Combine First + Last Name
            'login': email,
            'email': email,
            'password': password,
            'groups_id': [(6, 0, [portal_group.id])],  # Assign to Portal Group
        }

    def _save_user_extended(self, user, post):
        """ Save additional user details to x_res_user_extended and link to user """
        try:
            # Validate country-state relationship
            country_id = post.get('country_id')
            state_id = post.get('state_id')
            if state_id:
                state = request.env['res.country.state'].sudo().browse(int(state_id))
                if state.country_id.id != int(country_id):
                    raise UserError(_("Selected state does not belong to the chosen country"))

            # Create extended record
            extended_record = request.env['x_res_user_extended'].sudo().create({
                'user_id': user.id,
                'telephone': post.get('telephone'),
                'occupation': post.get('occupation'),
                'sales_rep': post.get('sales_rep'),
                'company': post.get('company'),
                'address1': post.get('address1'),
                'address2': post.get('address2'),
                'city': post.get('city'),
                'postcode': post.get('postcode'),
                'country_id': int(country_id) if country_id else False,
                'state_id': int(state_id) if state_id else False,
                'subscribe': post.get('subscribe') == 'on',
            })
            
            user.sudo().write({'extended_info_id': extended_record.id})
            
        except Exception as e:
            _logger.error("Error saving extended user info: %s", e)
            raise UserError(_("Error while saving additional user information. %s", e))


    @http.route('/customer/signup', type='http', auth='public', website=True)
    def customer_signup(self, **kwargs):
        """ Render the signup form with dynamic countries and states. """
        countries = request.env['res.country'].sudo().search([])
        states = request.env['res.country.state'].sudo().search([])
        return request.render('customer_registration.signup_form', {
            'countries': countries,
            'states': states
        })

    @http.route('/customer/signup/submit', type='http', auth='public', website=True, csrf=True)
    def customer_signup_submit(self, **post):
        """ Handle user registration form submission. """
        try:
            # Validate and prepare user data
            signup_values = self._prepare_signup_values(post)

            # Create the new user
            new_user = request.env['res.users'].sudo().create(signup_values)

            # Save extended information to x_res_user_extended
            self._save_user_extended(new_user, post)

            # Commit the transaction
            request.env.cr.commit()

            return request.render('customer_registration.signup_thank_you')

        except (UserError, SignupError) as e:
            _logger.warning("Signup validation error: %s", e)
            return request.render('customer_registration.signup_form', {
                'error': e.args[0],
                'post': post
            })

        except Exception as e:
            request.env.cr.rollback()  # Rollback transaction in case of failure
            _logger.exception("Unexpected error during customer signup: %s", e)
            return request.render('customer_registration.signup_form', {
                'error': _("An unexpected error occurred. Please try again later."),
                'post': post
            })
